#ifndef CircleDriver_H
#define CircleDriver_H
class CircleDriver
{
 public:
 void Run();
 private:
 Circle Circ1;
 Circle Circ2;
 void ObtainCircles();
 void PrintCirclesInfo();
};
#endif