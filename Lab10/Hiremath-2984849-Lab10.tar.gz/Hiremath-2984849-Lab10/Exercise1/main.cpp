#include <iostream>
#include "Circle.h"
#include "CircleDriver.h"

int main()
{
   CircleDriver myDriver;
   myDriver.Run();
   return(0);
}