#include <iostream>
	
int main()
{

	std::cout << "This is my first lab exercise!" << std::endl;

}
