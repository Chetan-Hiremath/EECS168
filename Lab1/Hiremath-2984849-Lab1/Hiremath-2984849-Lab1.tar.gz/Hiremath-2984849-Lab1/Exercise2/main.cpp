#include <iostream>

int main()
{
	std::cout << "My name is Chetan Hiremath." << std::endl;
        std::cout << "I am an EECS major." << std::endl;
        std::cout << "My hobbies are: " << std::endl;
        std::cout << "\tWatching movies" << std::endl;
        std::cout << "\tPlaying video games" << std::endl;
        std::cout << "\tPlaying sports" << std::endl;
        std::cout << "Goodbye!" << std::endl;
}

